# Simple Web App

This is a simple NodeJs web app built on top of express.js framework.

## Setup

Setup is as simple as:

```bash
npm install
# Run unit tests
npm run test
# Run the app
npm run start
```
